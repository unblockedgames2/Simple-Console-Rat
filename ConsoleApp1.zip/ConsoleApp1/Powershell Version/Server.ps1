# Setup listener on port 8080
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, 8080)
$listener.Start()
Write-Host "Server is listening on port 8080..."

# List to keep track of clients
$clients = @()
$currentIndex = -1

# Accept clients in a background job
$acceptClientsJob = Start-Job -ScriptBlock {
    param($listener)
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $remoteEndPoint = $client.Client.RemoteEndPoint.ToString()
        $clientInfo = [PSCustomObject]@{
            Client = $client
            Stream = $stream
            Id = [Guid]::NewGuid().ToString()
            IpAddress = $remoteEndPoint
        }
        $clientInfo
    }
} -ArgumentList $listener

# Receive clients from job and add to list
Register-ObjectEvent -InputObject $acceptClientsJob -EventName DataAdded -Action {
    $receivedClient = Receive-Job -Job $acceptClientsJob
    $clients += $receivedClient
    Write-Host "Client connected: $($receivedClient.Id) at $($receivedClient.IpAddress)"
}

# Function to display and interact with selected client
function DisplayCommandMenu {
    if ($currentIndex -lt 0 -or $currentIndex -ge $clients.Count) {
        Write-Host "No client selected."
        return
    }
    $selectedClient = $clients[$currentIndex]

    while ($true) {
        Write-Host "Commands for $($selectedClient.Id) at $($selectedClient.IpAddress)"
        Write-Host "1: Open Notepad"
        Write-Host "2: Get System Info"
        Write-Host "3: Custom Shell Command"
        Write-Host "4: Create File"
        Write-Host "5: Show IP"
        Write-Host "6: Exit Command Menu"
        Write-Host "Enter the number of the command to execute or exit:"

        $choice = Read-Host
        switch ($choice) {
            '1' { SendData $selectedClient "shell start notepad.exe" }
            '2' { SendData $selectedClient "getsysinfo" }
            '3' {
                $command = Read-Host "Type the command to execute"
                SendData $selectedClient "shell $command"
            }
            '4' {
                $filePath = Read-Host "Enter the path for the new file"
                SendData $selectedClient "file create $filePath"
            }
            '5' { SendData $selectedClient "shell curl api.ipify.org" }
            '6' { return }
            Default { Write-Host "Invalid command selection. Please try again." }
        }

        Write-Host "Press 'Enter' to return to the command menu or any other key to continue..."
        $key = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        if ($key.VirtualKeyCode -ne 13) { # Not Enter key
            break
        }
    }
}

# Main loop to interact with clients
while ($true) {
    $key = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    switch ($key.VirtualKeyCode) {
        38 { # Up Arrow
            if ($clients.Count -gt 0) {
                $currentIndex = ($currentIndex - 1 + $clients.Count) % $clients.Count
            }
        }
        40 { # Down Arrow
            if ($clients.Count -gt 0) {
                $currentIndex = ($currentIndex + 1) % $clients.Count
            }
        }
        13 { # Enter key
            DisplayCommandMenu()
        }
    }
    DisplayClients()
}

# Function to send data to a client
function SendData {
    param($clientInfo, $data)
    $stream = $clientInfo.Stream
    $writer = New-Object System.IO.StreamWriter($stream)
    $writer.WriteLine($data)
    $writer.Flush()
}

# Function to display clients
function DisplayClients {
    Clear-Host
    Write-Host "Server is listening on port 8080..."
    for ($i = 0; $i -lt $clients.Count; $i++) {
        if ($i -eq $currentIndex) {
            Write-Host "=> Client $($clients[$i].Id) at $($clients[$i].IpAddress)"
        } else {
            Write-Host "   Client $($clients[$i].Id) at $($clients[$i].IpAddress)"
        }
    }
}

# Ensure resources are cleaned up on exit
$listener.Stop()
Remove-Job -Job $acceptClientsJob -Force
